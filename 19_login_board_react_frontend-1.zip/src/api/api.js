import axios from 'axios';

// 기본 설정
const api = axios.create({
  baseURL: 'http://localhost:9080/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 요청 인터셉터 - 토큰이 있으면 자동 첨부
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 로그인 / 회원가입 등 POST 요청
export async function postAuth(path, body) {
  try {
    const res = await api.post(`/auth/${path}`, body);
    console.log("서버에서 넘어온 토큰정보:",res.data);
    return res; // JSON 자동 파싱됨
  } catch (err) {
    console.error('Auth 요청 실패:', err);
    throw err;
  }
}

// 현재 로그인된 사용자 정보 요청
export async function fetchMe() {
  try {
    const res = await api.get('/auth/me');
    return res;
  } catch (err) {
    console.error('사용자 정보 요청 실패:', err);
    throw err;
  }
}

export default api;
