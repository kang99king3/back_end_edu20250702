// src/auth.js
export function logout() {
  localStorage.removeItem('token');
  // 필요 시 서버 로그아웃 endpoint 호출 (if you use token blacklist)
  window.location.href='/login';
}
