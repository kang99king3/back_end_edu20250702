// src/pages/Home.jsx (간단 예시)
import React, { useEffect, useState } from 'react';
import { fetchMe } from '../api/api';
import { logout } from '../api/auth';

export default function Home() {
  const [user, setUser] = useState(null);

    useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;

    const loadUser = async () => {
        try {
        const res = await fetchMe(token); // axios 함수 호출
        const data = res.data; // axios는 res.data로 접근
        setUser(data);
        } catch (error) {
        console.error(error);
        // 401 등 인증 에러일 경우 토큰 삭제 후 로그아웃 처리
        if (error.response && error.response.status === 401) {
            localStorage.removeItem('token');
            setUser(null);
        }
        }
    };

    loadUser();
    }, []);
  return (
    <div style={{ maxWidth: 700, margin: '2rem auto' }}>
      <h3>Home</h3>
      {/* {user ? <pre>{JSON.stringify(user, null, 2)}</pre> : <div>Please login.</div>} */}
      {user ? <div>{user.id}님 로그인 중입니다.<button onClick={logout}>로그아웃</button>  </div> : <div>Please login.</div>}
    </div>
  );
}
