import React, { useState } from "react";
import { postAuth } from "../api/api";
import { Navigate, useNavigate } from "react-router-dom";


const SignupForm = () => {
  const [form, setForm] = useState({
    id: "",
    password: "",
    name: "",
    email: "",
    address: ""
  });

  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  // 입력값 변경 처리
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // 회원가입 submit
  /*
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await postAuth('signup', form);
      const data = await res.json();// fetch함수는 json객체로 변환해야 data속성이 생성됨
      console.log(data.id);
      setMessage(`회원가입 성공! ID: ${data.id}`);
      setForm({ id: "", password: "", name: "", email: "", address: "" });
      navigate('/');
    } catch (error) {
      console.error(error);
      if (error.response) {
        setMessage(`회원가입 실패: ${error.response.data.message || error.response.statusText}`);
      } else {
        setMessage("회원가입 실패: 서버와 연결할 수 없습니다.");
      }
    }
  };
*/
const handleSubmit = async (e) => {
  e.preventDefault();

  try {
    // axios는 자동으로 JSON 변환을 해줌
    const res = await postAuth('signup', form);
    const data = res.data; // axios는 응답 데이터가 res.data에 바로 들어감

    console.log(data.id);
    setMessage(`회원가입 성공! ID: ${data.id}`);
    setForm({ id: "", password: "", name: "", email: "", address: "" });
    navigate('/');

  } catch (error) {
    console.error(error);

    if (error.response) {
      setMessage(`회원가입 실패: ${error.response.data.message || error.response.statusText}`);
    } else if (error.request) {
      setMessage("회원가입 실패: 서버로부터 응답이 없습니다.");
    } else {
      setMessage(`회원가입 실패: ${error.message}`);
    }
  }
};
  return (
    <div style={{ maxWidth: "400px", margin: "0 auto" }}>
      <h2>회원가입</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>ID:</label>
          <input name="id" value={form.id} onChange={handleChange} required />
        </div>
        <div>
          <label>비밀번호:</label>
          <input type="password" name="password" value={form.password} onChange={handleChange} required />
        </div>
        <div>
          <label>이름:</label>
          <input name="name" value={form.name} onChange={handleChange} required />
        </div>
        <div>
          <label>이메일:</label>
          <input type="email" name="email" value={form.email} onChange={handleChange} required />
        </div>
        <div>
          <label>주소:</label>
          <input name="address" value={form.address} onChange={handleChange} />
        </div>
        <button type="submit">회원가입</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default SignupForm;
