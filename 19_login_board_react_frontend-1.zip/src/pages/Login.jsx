// src/pages/Login.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { postAuth } from '../api/api';

export default function Login() {
  const [form, setForm] = useState({ id: '', password: '' });
  const [msg, setMsg] = useState('');
  const navigate = useNavigate();

  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });
/*
  const onSubmit = async (e) => {
    e.preventDefault();
    setMsg('');

    try {
      const res = await postAuth('login', form);

      if (!res.ok) {
        // 서버가 JSON으로 MessageResponse를 내려주는 경우
        let data;
        try { data = await res.json(); } catch { data = null; }
        setMsg((data && data.message) ? data.message : `Login failed (${res.status})`);
        return;
      }

      const data = await res.json();
      const token = data.token;
      if (!token) {
        setMsg('No token received from server');
        return;
      }
      console.log("token",token);
      // 토큰 저장 (실무: httpOnly cookie 권장)
      localStorage.setItem('token', token);
      console.log('저장된토큰:',localStorage.getItem('token'));
      // 리디렉트 / 사용자 정보 로드 등
      navigate('/');
    } catch (err) {
      console.error(err);
      setMsg('Network error');
    }
  };
*/
const onSubmit = async (e) => {
  e.preventDefault();
  setMsg('');

  try {
    // axios는 상태 코드 200~299 외에는 자동으로 예외를 던짐
    const res = await postAuth('login', form);
    const data = res.data; // 응답 데이터는 여기 들어감

    const token = data.token;
    if (!token) {
      setMsg('서버에서 토큰을 받지 못했습니다.');
      return;
    }

    console.log("token", token);

    // 토큰 저장 (실무에서는 httpOnly 쿠키 권장)
    localStorage.setItem('token', token);
    console.log('저장된토큰:', localStorage.getItem('token'));

    navigate('/'); // 로그인 성공 시 메인 페이지로 이동

  } catch (error) {
    console.error(error);

    if (error.response) {
      // 서버에서 에러 응답(JSON) 보낸 경우
      const message =
        error.response.data?.message ||
        `로그인 실패 (${error.response.status})`;
      setMsg(message);
    } else if (error.request) {
      // 요청은 갔지만 응답이 없을 때
      setMsg('서버 응답이 없습니다.');
    } else {
      // 요청 자체에서 예외가 발생했을 때
      setMsg(`에러 발생: ${error.message}`);
    }
  }
};
  return (
    <div style={{ maxWidth: 420, margin: '2rem auto' }}>
      <h3>Login</h3>
      <form onSubmit={onSubmit}>
        <div>
          <input
            name="id"
            placeholder="id"
            value={form.id}
            onChange={onChange}
            required
            style={{ width: '100%', padding: 8, marginBottom: 8 }}
          />
        </div>
        <div>
          <input
            name="password"
            placeholder="password"
            type="password"
            value={form.password}
            onChange={onChange}
            required
            style={{ width: '100%', padding: 8, marginBottom: 8 }}
          />
        </div>
        <button type="submit" style={{ padding: '8px 16px' }}>Login</button>
      </form>
      <div style={{ color: 'red', marginTop: 12 }}>{msg}</div>
    </div>
  );
}
