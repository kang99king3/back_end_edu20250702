import React from 'react';
import '../../assets/Sidebar.css';
import { Link } from 'react-router-dom';

function Sidebar() {
  return (
    <aside className="sidebar">
      <h2>Sidebar</h2>
      <ul>
        <li><Link to="/board">게시판</Link></li>
        <li><a href="#link2">Link 2</a></li>
        <li><a href="#link3">Link 3</a></li>
      </ul>
    </aside>
  );
}

export default Sidebar;