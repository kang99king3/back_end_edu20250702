import React from 'react';
import '../../assets/Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2023 My Website. All rights reserved.</p>
    </footer>
  );
}

export default Footer;