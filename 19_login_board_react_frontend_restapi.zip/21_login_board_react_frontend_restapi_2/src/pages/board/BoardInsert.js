import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { deleteBoard, getBoardDetail, insertBoard, updateBoard } from '../../services/BoardService';

const BoardInsert = () => {
    //로그인 id가 저장되어 있는 localStorage에서 가져오기
    const loginId=localStorage.getItem("id");

    const [boardDetail,setBoardDetail]=useState({});
    const [selectedFile, setSelectedFile]=useState(null);
    const navigate=useNavigate();

    //수정내용 입력 저장
    const onChange = (e)=>{
        const {name, value}=e.target;
        
        if(name==="title"){
            setBoardDetail({
                            'id':loginId,
                            'title':value,
                            'content':boardDetail.content,
                            })
        }
        if(name==="content"){
            setBoardDetail({
                            'id':loginId,
                            'title':boardDetail.title,
                            'content':value,
                            })
        }
        // if(name==="file"){
        //     setBoardDetail({
        //                     'id':loginId,
        //                     'title':boardDetail.title,
        //                     'content':boardDetail.content,
        //                     'filename':value,
        //     })
        // }
    }

    const handleFileChange = (e)=>{
        //e.target.files 반환타입은 FileList객체임-->배열로 변환하는 작업 필요
        const file= Array.from(e.target.files);
        console.log("selected File:",file);
        setSelectedFile(file);
    }

    //글추가 요청 처리
    const insertHandler=(e)=>{
        e.preventDefault();
        if(window.confirm("글을 추가 하시겠습니까?")){
            //파라미터와 파일데이터를 함께 전송하려면 반드시 FormData()사용
            const formData = new FormData();
            formData.append('id',boardDetail.id);
            formData.append('title',boardDetail.title);
            formData.append('content',boardDetail.content);
            if(selectedFile!==null){
                selectedFile.forEach((file,index) => {
                    formData.append('filename',file);
                });
            }
            insertBoard(formData).then(
                response=>{
                    console.log(response);
                    if(response){
                        alert("글 추가 완료!");
                        navigate("/board");
                    }else{
                        alert("글 추가 실패");
                        navigate("/login");
                    }
                }
            )
        }
    }

    return (
        <div className='table-container'>
            <form onSubmit={insertHandler}>
                <table className='custom-table'>
                    <tbody>
                        <tr>
                            <td>작성자</td>
                            <td><input type="text" name="id" value={loginId} readOnly /></td>
                        </tr>
                        <tr>
                            <td>파일</td>
                            <td><input type="file" name="filename" multiple="multiple" onChange={handleFileChange} /></td>
                        </tr>
                        <tr>
                            <td>제목</td>
                            <td><input type="text" name='title' value={boardDetail.title||""} onChange={onChange}/></td>
                        </tr>
                        <tr>
                            <td>내용</td>
                            <td><textarea cols={60} rows={10} name='content' value={boardDetail.content||""} onChange={onChange}></textarea></td>
                        </tr>
                    </tbody>
                    <tfoot> 
                        <tr>
                            <td colSpan={2}>
                                <input className='button' type="submit" value="글추가"/>
                            </td>  
                        </tr>               
                    </tfoot> 
                </table>
            </form>
        </div>
    );
};

export default BoardInsert;