import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { deleteBoard, getBoardDetail, updateBoard } from '../../services/BoardService';

const BoardDetail = () => {
    //로그인 id가 저장되어 있는 localStorage에서 가져오기
    const loginId=localStorage.getItem("id");

    const [boardDetail,setBoardDetail]=useState({});
    const navigate=useNavigate();

    //수정내용 입력 저장
    const onChange = (e)=>{
        const {name, value}=e.target;
        if(name==="title"){
            setBoardDetail({'board_seq':boardDetail.board_seq,
                            'id':boardDetail.id,
                            'title':value,
                            'content':boardDetail.content,
                            'regdate':boardDetail.regdate
                            })
        }
        if(name==="content"){
            setBoardDetail({'board_seq':boardDetail.board_seq,
                            'id':boardDetail.id,
                            'title':boardDetail.title,
                            'content':value,
                            'regdate':boardDetail.regdate
                            })
        }
    }

    //수정 요청 처리
    const updateHandler=(e)=>{
        e.preventDefault();
        if(window.confirm("수정하시겠습니까?")){
            console.log(boardDetail.board_seq);
             updateBoard(boardDetail).then(
                response=>{
                    console.log(response.status);
                    if(response.status===201){
                        alert("글 수정 완료!");
                    }else{
                        alert("글 수정 실패");
                    }
                }
            )
        }
    }


    //상세내용 실행
    useEffect(()=>{
        // const response = getBoardList();
        // console.log("a")
        // setBoardList(response.data['list']);
        response();
    },[]);

    //상세내용 처리를 위한 파라미터 받기
    let {seq} = useParams();
    //상세내용 요청 처리
    // async await 사용하여 처리하기
    // const response = async () =>{
    //    let result= await getBoardDetail(seq);
    //    if(result){
    //        setBoardDetail(result.data.dto);
    //    }else{
    //         navigate('/board');
    //    }
    // }
    // then()을 사용하여 처리하기
    // - axios는 promise기반으로 비동기방식으로 처리한다. 
    //   그래서 async-await 또는 then()을 이용하여 처리해야 함
    const response = () =>{
        getBoardDetail(seq).then(res=>{
            console.log("파일이름:",res.data.dto.fileBoardList[0].origin_filename);
            console.log("상세내용:",res.data.dto);
            setBoardDetail(res.data.dto);
            // console.log(boardDetail);
        })
        .catch(error=>{
            console.log(error);
            navigate('/board');
        })
        .finally(()=>{
            console.log("작업완료!!");
        })
       
     }
     
    const delBoard=()=>{
        if(window.confirm("정말 삭제 하시겠습니까?")){
            deleteBoard([boardDetail.board_seq]).then(res=>{
                navigate('/board');
            })
            .catch(error=>{
                console.log(error.message);
            })
        }
    }

    return (
        <div className='table-container'>
            <form onSubmit={updateHandler}>
                <table className='custom-table'>
                    <tbody>
                        <tr>
                            <td>번호</td>
                            <td>{boardDetail.board_seq}</td>
                        </tr>
                        <tr>
                            <td>작성일</td>
                            <td>{boardDetail.regdate}</td>
                        </tr>
                        <tr>
                            <td>작성자</td>
                            <td>{boardDetail.id}</td>
                        </tr>
                        <tr>
                            <td>제목</td>
                            <td><input type="text" name='title' value={boardDetail.title||""} onChange={onChange}/></td>
                        </tr>
                        <tr>
                            <td>파일</td>
                            {/* userEffect는 렌더링 후 실행되기때문에 첫 렌더링때 boardDetail.fileBoardList나 fileBoardList[0] 코드가 실행될때 오류가 발생한다.
                                jsx에서는 객체를 직접 출력하려고 하면 오류가 발생, undefined는 하나의 값이라 오류없이 공백으로 표현됨
                            */}
                            <td>{boardDetail.fileBoardList && boardDetail.fileBoardList[0].origin_filename?
                                                 boardDetail.fileBoardList.map((item,index)=>(
                                                        <a key={index}
                                                           href="/download"  
                                                           rel="noopener noreferrer" 
                                                           style={{ marginRight: "5px" }}
                                                        >[{item.origin_filename}]</a>
                                                    )):"첨부파일없음"}</td>
                        </tr>
                        {/* <tr>
                            <td>파일</td>
                            <td><img src='http://localhost:9090/upload/173b58b3-b75a-436f-9ed8-01da08c1fd11.jpg' alt="이미지" /></td>
                        </tr> */}
                        <tr>
                            <td>내용</td>
                            <td><textarea cols={60} rows={10} name='content' value={boardDetail.content||""} onChange={onChange}></textarea></td>
                        </tr>
                    </tbody>
                    <tfoot> 
                        {loginId===boardDetail.id&&
                            <tr>
                                <td colSpan={2}>
                                    <input className='button' type="submit" value="수정"/>&nbsp;&nbsp;
                                    <input className='button' type="button" value="삭제" onClick={delBoard}/>
                                </td>  
                            </tr>               
                        }
                    </tfoot> 
                </table>
            </form>
        </div>
    );
};

export default BoardDetail;