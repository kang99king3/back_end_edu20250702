import { useEffect, useState } from 'react';

import { BrowserRouter, Link, Navigate, Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import "./assets/App.css";
import Layout from './components/layouts/Layout';
import BoardList from './pages/board/BoardList';
import BoardDetail from './pages/board/BoardDetail';
import BoardInsert from './pages/board/BoardInsert';


//Hooks: useEffect-렌더링후 실행, useState-값이 변경될때마다 렌더링 실행

function App() {
  //state의 상태가 변경되면 리렌더링이 발생한다.
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true); // 로딩 상태 추가

  // 로그인 상태를 확인하는 함수
  //effect()는 렌더링 후 실행된다.
  useEffect(() => {
    console.log("useEffect");
    const token = localStorage.getItem('id');
    setIsAuthenticated(!!token); // 토큰이 있으면 true, 없으면 false
    setIsLoading(false); // 로딩 완료
  }, []);
  
  // const handleLogout = () => {
  //   localStorage.removeItem('id');
  //   setIsAuthenticated(false);
  // };
  
  // 보호된 라우트를 렌더링하는 컴포넌트: 로그인상태가 아니면 login페이지로 요청
  // 처음 렌더링 될때 실행하면 isLoading의 값이 true이다. 그래서 null로 렌더링되는게 없음
  // 그다음 렌더링이 끝나고 나면 useEffect가 실행되면서 isLoading의 값을 false로 변경해주고 
  // --> state의 값이 변경되니깐 리렌더링이 되면서 isLoading값이 false이므로 <Homepage/>를 보여주게 됨
  // 실행 순서: PrivateRoute -> useEffect -> PrivateRoute -> homepage
  const PrivateRoute = ({children}) => {
    console.log("PrivateRoute");
    if (isLoading) return null; // 로딩 중에는 아무것도 렌더링하지 않음
    return isAuthenticated ? children : <Navigate to="/login" />;
  };

  return (
    <BrowserRouter>
      <div>
          <nav>
              {/* <a href="/home">Home</a> */}
              {/* <Link to='/home' >HOME</Link> */}
              {/* {isAuthenticated && <button onClick={handleLogout}>Logout</button>} */}
          </nav>
          <Routes>
              <Route path="/login" element={<LoginPage isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated}/>} />
              <Route path="/" element={<Layout isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated}/>}>
                <Route path="board"  >
                  <Route index element={<BoardList/>} />
                  <Route path="boardinsert" element={<BoardInsert/>} />
                  <Route path="detail/:seq" element={<BoardDetail/>} />
                </Route>
              </Route>
              {/* <Route 
                  path="/home" 
                  element={
                      <PrivateRoute >
                          <HomePage isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated} />
                      </PrivateRoute>
                  } 
              /> */}
              {/* 모든 요청에 대해 /home을 요청하도록 함-->로그인상태확인해서 homepage 또는 로그인페이지로 이동 */}
              {/* <Route path="*" element={<Navigate to="/home" replace />} /> */}
              <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
      </div>
  </BrowserRouter>
  );
}


export default App;
