import axios from 'axios';
import React from 'react';

const apiURL="http://localhost:9090";

const instance = axios.create({
    baseURL:apiURL,
    headers:{"Content-Type":"application/json"},
    withCredentials:true,
});

// const accessInstance = axios.create({
//     baseURL: apiURL,
//     headers: {
//       "Content-Type": "application/json",
//     },
//   });

export const login = async (pageParams) => {
    // const response1 = await instance.get(`/products/?page=${pageParams}`);
    console.log(pageParams);
    // const response = await instance.post('/user/login',null, {"id":"hk","password":"12345678"});
    const response = await instance.post('/user/login', pageParams );
    console.log(response.data['id']);
    return response;
  };

  export const logOut = async () => {
    const response = await instance.put('/user/logout');
    console.log(typeof response.status)
    return response;
  }; 

  