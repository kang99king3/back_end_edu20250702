// store.js
import { configureStore } from '@reduxjs/toolkit';
import authReducer from './reducers/authReducer';

const store = configureStore({
  reducer: {
    auth: authReducer,  // authReducer를 auth로 등록
  },
});

export default store;